console.log("yes")

var frame = Snap("#svg");



var lineStart = [d="M380.7,31.8l-1.1,2.1l0,0L380.7,31.8L380.7,31.8z"]
var lineEnd = [d="M380.7,31.8l-1.1,2.1H145.3v-2.1H380.7z"]
var line = frame.path(lineStart)
						.attr({
							fill: "#000000",
							// stroke: "#cccccc",
							// strokeWidth: 12,
				  			class: "thing"
						});	

var slashStart = [d="M379.5,33.9L379.5,33.9H309l0,0H379.5z"]
var slashEnd = [d="M379.5,33.9L108.4,513.7H37.9L309,33.9H379.5z"]
var slash = frame.path(slashStart)
						.attr({
							fill: "#62b7ad",
							// stroke: "#cccccc",
							// strokeWidth: 12,
				  			class: "thing"
						});


var ball = frame.circle(145.3, 212.5, 0)
						.attr({
							fill: "#ee7130",
							// stroke: "#cccccc",
							// strokeWidth: 12,
				  			class: "thing"
						});


function playLine(){
	line.animate({d: lineEnd}, 1000, mina.easein);
};

function playSlash(){
	slash.animate({d: slashEnd}, 1000, mina.easein);
};

function playBall(){
	ball.animate({r: 47}, 1000, mina.easein);
};



setInterval(function(){
	playLine();
}, 500)

setInterval(function(){
	playSlash();
}, 580)

setInterval(function(){
	playBall();
}, 600)